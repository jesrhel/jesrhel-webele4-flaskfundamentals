from flask import Flask, render_template
from forms import LoginForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'jesrhel'


@app.route('/')
def home():
    return 'Hello World! <a href="/login">Login now?</a>'


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if form.email.data == 'test@flask.app' and form.password.data == 'password123':
            return render_template('success.html')
        else:
            return render_template('fail.html')
    return render_template('login.html', form=form)


if __name__ == '__main__':
    app.run()
